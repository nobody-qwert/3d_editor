//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Editor.rc
//
#define IDR_MENU                        101
#define IDD_TEXTURE_PROPERTIES          101
#define IDD_SMOOTHNESS                  102
#define IDD_TOOLDIALOG                  103
#define IDD_LIGHT_PROPERTIES            103
#define IDD_LOAD_CATALOG                104
#define IDI_3DW                         104
#define IDC_NEWOBJECT                   1001
#define IDC_BEZIER                      1002
#define IDC_PRIMITIVES                  1003
#define IDC_OK1                         1035
#define IDC_CANCEL                      1037
#define IDC_T                           1038
#define IDC_HS                          1040
#define IDC_VS                          1041
#define IDC_W                           1042
#define IDC_H                           1043
#define IDC_SCROLL                      1048
#define IDC_OK                          1049
#define IDC_ST                          1051
#define IDC_RED                         1052
#define IDC_GREEN                       1053
#define IDC_BLUE                        1054
#define IDC_X                           1055
#define IDC_Y                           1056
#define IDC_Z                           1057
#define IDC_R                           1058
#define IDC_B                           1059
#define IDC_C                           1060
#define IDC_LIST                        1063
#define IDC_BILLBOARD                   1065
#define IDM_FILE_EXIT                   40002
#define ID_FILE_EXIT                    40002
#define ID_TEXTURES_LOADFROMFILE        40003
#define ID_CREATE_BEVEL                 40014
#define ID_CREATE_ENDCAP                40016
#define ID_CREATE_CONE                  40021
#define ID_CREATE_CILINDER              40022
#define ID_CREATE_SIMPLEMESH            40023
#define ID_CREATE_SPHERE                40025
#define ID_TEXTURES_TEXTURINGPROPERTIES 40029
#define ID_OBJECT_SMOOTHNESS            40030
#define ID_VIEW_LEFT                    40033
#define ID_VIEW_FRONT                   40034
#define ID_VIEW_TOP                     40035
#define ID_CREATE_CAPS_BEVEL            40036
#define ID_CREATE_CAPS_ENDCAP           40037
#define ID_SELECT_DRAGVERTICES          40038
#define ID_FILE_RESET                   40043
#define ID_EDIT_ROTATE                  40045
#define ID_CREATE_CAPS_INVERTEDBEVEL    40048
#define ID_CREATE_CAPS_INVERTEDENDCAP   40049
#define ID_EDIT_SNAPTOGRID              40050
#define ID_SELECT_SELECTINSIDE          40051
#define ID_TEXTURES_LOCKTEXTURE         40052
#define ID_TEXTURES_LOCKTEXTURE_ROTATIONS 40053
#define ID_LIGHTS_INSERTLIGHT           40054
#define ID_LIGHTS_MODIFYSELECTEDLIGHT   40055
#define ID_LIGHTS_GENERATE_LIGHTMAPS    40056
#define ID_EDIT_DUPLICATE               40057
#define ID_EDIT_DELETE                  40058
#define ID_VIEW_SHOWLIGHTMAPS           40059
#define ID_FILE_OPEN1                   40063
#define ID_FILE_SAVE1                   40064
#define ID_EDIT_INSERTOBJECT            40065
#define ID_EDIT_SCALEOBJECTS            40066
#define ID_TEXTURES_LOCKTEXTURE_MOVES   40067
#define ID_VIEW_GLPOINT                 40069
#define ID_VIEW_GLLINE                  40070
#define ID_VIEW_GLFILL                  40071
#define ID_VIEW_BULBS                   40072

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40073
#define _APS_NEXT_CONTROL_VALUE         1066
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
